#define _CRT_SECURE_NO_WARNINGS		//Included to overcome the scanf warnings in the code
#include "fundamentals.h"
#define MAX_LENGTH 80				//Including the Header file


/* Version 1 */
void fundamentals() {	
	printf("*** Start of Indexing Strings Demo ***\n");
    char buffer1[80];
    char num_input[10];
    unsigned int position;

    printf("Type not empty string (q - to quit):\n");
    printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");
    gets(buffer1);

    while (strcmp(buffer1, "q") != 0) {
        printf("Type the characer position within the string:\n");
        gets(num_input);
        position = atoi(num_input);

        if (position >= strlen(buffer1)) {
            position = strlen(buffer1) - 1;
            printf("Too big... Position reduced to max. available\n");
        }
        printf("The character found at %d position is \'%c\'\n", position, buffer1[position]);

        printf("Type not empty string (q - to quit):\n");
        printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");
        gets(buffer1); // Reads user input into buffer1
    }
    printf("*** End of Indexing Strings Demo ***\n\n");


/* Version 2 */

	printf("*** Start of Measuring Strings Demo ***\n");					
	char buffer2[80];														//Creating a character type array "buffer2" which can hold upto 79 characters, and 1 extra space for the null character
	printf("Type a string (q - to quit):\n");
	gets(buffer2);															//Gets the input from the user and store it in array "buffer2"
	while (strcmp(buffer2, "q") != 0){										//A while loop which will be executed unless and until buffer2's value is equal to "q"; if q is entered, the program will end.
		printf("The length of the string is %lu\n", strlen(buffer2));						
		printf("Type a string (q - to quit):\n");
		gets(buffer2);											
	}
	printf("*** End of Measuring Strings Demo ***\n\n");					
													
/* Version 3 */

    printf("*** Start of Copying Strings Demo ***\n");
    char destination[MAX_LENGTH] = ""; // Initialize as empty
    char source[MAX_LENGTH];

    printf("Destination string is reset to empty.\n");
    printf("Type a source string (q - to quit):\n");
    while (fgets(source, MAX_LENGTH, stdin)) {
        source[strcspn(source, "\n")] = '\0'; // Remove trailing newline

        if (strcmp(source, "q") == 0) break;

        // Use strncpy to prevent buffer overflow
        strncpy(destination, source, MAX_LENGTH - 1);
        destination[MAX_LENGTH - 1] = '\0'; // Ensure null termination

        printf("New destination string is '%s'\n", destination);
        printf("Destination string is reset to empty.\n");
        destination[0] = '\0'; // Reset the destination string
        printf("Type a source string (q - to quit):\n");
    }
    printf("*** End of Copying Strings Demo ***\n\n");
}


