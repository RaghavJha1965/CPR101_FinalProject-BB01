/*This is the header file which will contain the function prototypes
  that are going to be used in converting.c file  */
#ifndef _CONVERTING_H            // safeguarding the header file
#define _CONVERTING_H

  //including the header files----
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void converting();             //declaring the function protoytpe

#endif