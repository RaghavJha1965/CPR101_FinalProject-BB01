#define _CRT_SECURE_NO_WARNINGS // Avoid warnings for simplicity
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void converting() {
    printf("*** Start of Converting Strings to long Demo ***\n");
    char long_string[80]; // Character array for user input
    long long_number;

    printf("Type the long numeric string (q - to quit):\n");
    while (fgets(long_string, sizeof(long_string), stdin)) {
        // Remove newline character if present
        long_string[strcspn(long_string, "\n")] = '\0';

        if (strcmp(long_string, "q") == 0) {
            break; // Exit loop if 'q' is entered
        }

        // Validate input and convert
        if (isdigit(long_string[0]) || (long_string[0] == '-' && isdigit(long_string[1]))) {
            long_number = atol(long_string);
            printf("Converted number is %ld\n", long_number);
        } else {
            printf("Invalid numeric string. Please try again.\n");
        }

        printf("Type the long numeric string (q - to quit):\n");
    }

    printf("*** End of Converting Strings to long Demo ***\n\n");
}
